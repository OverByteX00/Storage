<?php

class TestModel
{

    public function testFunc()
    {

        return 'Test Models';

    }

}