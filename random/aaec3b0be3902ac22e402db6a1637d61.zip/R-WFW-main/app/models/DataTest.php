<?php

class DataTest
{

    public function addData()
    {

        //

    }

    public function viewData()
    {

        //

    }

}