    <div class="container mt-5 p-5 shadow" style="font-size: 15px;">

        <div>
            <span style="font-weight: bold;">Parameter Test</span>
            <hr class="mb-3" />
            <span>
               Output:
               <br />
               <?=$data['result']; ?>
            </span>
            <hr class="mb-3" />
        </div>

    </div>