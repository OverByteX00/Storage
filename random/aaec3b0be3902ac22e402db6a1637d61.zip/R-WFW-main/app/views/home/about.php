    <div class="container mt-5 p-5 shadow" style="font-size: 15px;">

        <div>
            <span style="font-weight: bold;">About Us</span>
            <hr class="mb-3" />
            <span>
                We are an organization that was founded on December 20, 2015. Not only Information Technology is the topic of our organization, but we also discuss everything about science, technology, cyber security, hacking, social, outlook on life and etc.
            </span>
            <hr class="mb-3" />
        </div>

    </div>