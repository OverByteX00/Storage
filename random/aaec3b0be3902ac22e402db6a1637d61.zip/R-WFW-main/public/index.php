<?php

if (!session_id()) session_start();

require_once('../app/index.php');
